#!/usr/bin/env python
# coding: utf-8

# *  Author: Bhanushikha Rathore

# # 1. Polar Co-ordinate

# In[1]:


import cmath
z1=complex(input())
z2=complex(z1)
print(cmath.polar(z2)[0])
print(cmath.polar(z2)[1])


# # 2. Find Angle MBC

# In[ ]:


import math
ab=int(input())
bc=int(input())
ac=int()
ac=math.sqrt(ab*ab+bc*bc)
mc=float(0.5*ac)
#angle is sin(mc/bc)
result=int(round(math.degrees(math.asin(mc/bc))))
result=str(result)
print(result+chr(176))


# # 3 Mod divmod

# In[ ]:


a=int(input())
b=int(input())
c=divmod(a,b)
d,e=c
print(d)
print(e)
print(c)


# # 4 Power- Mod Power

# In[ ]:


a=int(input())
b=int(input())
m=int(input())
print(pow(a,b))
print(pow(a,b,m))


# # 5 Integers Come In All Sizes

# In[ ]:


a=int(input())
b=int(input())
c=int(input())
d=int(input())
e=pow(a,b)+pow(c,d)
print(e)


# # 6 Triangle Quest

# In[ ]:


for i in range(1,int(input())): #More than 2 lines will result in 0 score. Do not leave a blank line also
    print(int(i * 10**i // 9))


# # 7 Triangle Quest 2

# In[ ]:


for i in range(1,int(input())+1): 
    print(int(((10**i-1)/(9))**2))


#!/usr/bin/env python
# coding: utf-8

# # 1

# In[ ]:


print("Hello, World!")


# # 2 

# In[ ]:


n=int(input())
if n%2==1:
    print('Weird')
elif n%2==0 & 1<n<6:
    print("Not Weird")
elif n%2==0 & 5<n<21:
    print("Weird")
else:
    print("Not Weird")


# # 3

# In[ ]:


a=int(input())
b=int(input())
print(a+b)
print(a-b)
print(a*b)


# # 4

# In[ ]:


a = int(input())
   b = int(input())
   print(a//b)
   print(a/b)


# # 5

# In[ ]:


n = int(input())
   for i in range(0,n):
       print(i*i)


# # 6

# In[ ]:


def is_leap(year):
   leap = False

   if year%4==0:
       if year%100==0:
           if year%400==0:
               leap=True
           else:
               leap=False
       else:
           leap=True
   else:
       leap=False
           
   return leap

year = int(input())


# # 7

# In[ ]:


n = int(input())
for i in range(1,n+1):
    print(i, end='')


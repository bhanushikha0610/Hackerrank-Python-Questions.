#!/usr/bin/env python
# coding: utf-8

# 
# 
# # 1

# In[3]:


x = int(input())
y = int(input())
z = int(input())
n = int(input())
for i in range (x+1):
    for j in range(y+1):
        for k in range(z+1):
            if i+j+k==n:
                pass8
                n
                9
                
            else:
                print([i,j,k],",", end="")


# # 2

# In[ ]:


for _ in range(int(input())):
        name = input()
        score = float(input())
        for for_in in range:
            list=[[name,score]]
            list.sort()
for p in list:
    print(list)
    
        


# # 3

# In[ ]:


for _ in range(int(input())):
        name = input()
        score = float(input())
        list=[]
        list.append([name,score])
        list.sort()
        print(list)


# # 4

# In[ ]:


if __name__ == '__main__':
    N = int(input())
    Output = [];
    for i in range(0,N):
        ip = input().split();
        if ip[0] == "print":
            print(Output)
        elif ip[0] == "insert":
            Output.insert(int(ip[1]),int(ip[2]))
        elif ip[0] == "remove":
            Output.remove(int(ip[1]))
        elif ip[0] == "pop":
            Output.pop();
        elif ip[0] == "append":
            Output.append(int(ip[1]))
        elif ip[0] == "sort":
            Output.sort();
        else:
            Output.reverse();


# # 5

# In[ ]:


n = int(raw_input())
   integer_list = map(int, raw_input().split())
   print (hash(tuple(integer_list)))


# # 6

# In[26]:


def average(array):
    s=set(array)
    return sum(s)/len(s)# your code goes here

if __name__ == '__main__':
    n = int(input())
    arr = list(map(int, input().split()))
    result = average(arr)
    print(result)


# # 7

# In[ ]:


n,m = list(map(int,input().split()))
happiness = 0
arr = list()
A,B = set(),set()

arr = list(map(int,input().strip().split()))
A = set(map(int,input().strip().split()))
B = set(map(int,input().strip().split()))

for i in arr:
if i in A:
happiness += 1
elif i in B:
happiness -= 1
print(happiness)


# # 8

# In[ ]:


a,b = [set(input().split()) for _ in range(4)][1::2]
print('\n'.join(sorted(a^b, key=int)))


# # 9

# In[ ]:


rupal=int(input()) #7
lst=[]
for i in range(0,rupal):
    country=input()
    lst.append(country)
print(len(set(lst)))


# # 10

# In[ ]:


n = input()
s = set(map(int, input().split()))
for i in range(int(input())):
    c = input().split()
    if c[0] == 'pop':
        s.pop()
    elif c == 'remove':
        s.remove(int(c[1]))
    else:
        s.discard(int(c[1]))
print(sum(s))


# # 11

# In[ ]:


N1 = int(input())
storage1 = set(input().split());

N2 = int(input())
storage2 = set(input().split());

storage3 = storage1.union(storage2)

print(len(storage3))


# # 12

# In[ ]:


n1=input()
li1 = input().split()
s1 = set(li1)
n2=input()
li2 = input().split()
s2 = set(li2)
s1s2 = s1.intersection(s2)
print(len(s1s2))


# # 13

# In[ ]:


s=int(input())
j=set(input().split())
s1=int(input())
k=set(input().split())
l=j.difference(k)
print(len(l))


# # 14

# In[ ]:


s1=int(input())
i=set(input().split())
s2=int(input())
j=set(input().split())
k=i.symmetric_difference(j)
print(len(k))


# # 15

# In[ ]:


en_set = int(input())

storage = set(map(int, input().split()))

op_len = int(input())

for i in range(op_len):
    operation = input().split()
    if operation[0] == 'intersection_update':
        temp_storage = set(map(int, input().split()))
        storage.intersection_update(temp_storage)
    elif operation[0] == 'update':
        temp_storage = set(map(int, input().split()))
        storage.update(temp_storage)
    elif operation[0] == 'symmetric_difference_update':
        temp_storage = set(map(int, input().split()))
        storage.symmetric_difference_update(temp_storage)
    elif operation[0] == 'difference_update':
        temp_storage = set(map(int, input().split()))
        storage.difference_update(temp_storage)
    else :
        assert False

print(sum(storage))


# # 16

# In[ ]:


N = int(input())

m = mamp(int, input().split())
m = sorted(m)

for i in range(len(storaga)):
    if(i != len(m)-1
        if(m[i]!=m[i-1] and m[i]!=m[i+1]):
            print(m[i])
            break;
    else:
        print(m[i])


# # 17

# In[ ]:


T = int(input())

for _ in range(T):
    a = input()
    A = set(input().split())
    b = int(input())
    B = set(input().split())
    print(A.issubset(B))


# # 18

# In[ ]:


A = set(input().split())
print(all([A.issuperset(set(input().split())) for _ in range(int(input()))]))


# # 19

# In[ ]:


n=int(input())
m=sorted(set(input().split()))
print(m[-2])


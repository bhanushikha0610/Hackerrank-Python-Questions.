#!/usr/bin/env python
# coding: utf-8

# # 1. sWAP cASE

# In[ ]:


def swap_case(s):
    swap = ''
    for ch in s:
        if ch.isupper():
            swap += ch.lower()
        else:
            swap += ch.upper()
    return swap

if __name__ == '__main__':
    s = input()
    result = swap_case(s)
    print(result)


# # 2. What's Your Name?

# In[ ]:


def print_full_name(first, last):
    print("Hello ",first," ",last,"! You just delved into python.",sep='')
    
       
if __name__ == '__main__':
    first_name = input()
    last_name = input()
    print_full_name(first_name, last_name)


# # 3. Mutations

# In[ ]:


def mutate_string(string, position, character):
    string = string[:position] + character + string[position+1:]
    return string

if __name__ == '__main__':
    s = input()
    i, c = input().split()
    s_new = mutate_string(s, int(i), c)
    print(s_new)


# # 4 Find a string

# In[ ]:


def count_substring(string, sub_string):
    count = 0
    for i in range(0,len(string)):
        if string[i:i+len(sub_string)] == sub_string :
            count += 1
    return count

if __name__ == '__main__':
    string = input().strip()
    sub_string = input().strip()
    
    count = count_substring(string, sub_string)
    print(count)


# # 5 String Validators

# In[ ]:


def fun1(s):
    for i in range(len(s)):
        if(s[i].isalnum()):
            return True;
            break;
    return False;
        
def fun2(s):
    for i in range(len(s)):
        if(s[i].isalpha()):
            return True;
            break;
    return False;

def fun3(s):
    for i in range(len(s)):
        if(s[i].isdigit()):
            return True;
            break;
    return False;

def fun4(s):
    for i in range(len(s)):
        if(s[i].islower()):
            return True;
            break;
    return False; 
     
def fun5(s):
    for i in range(len(s)):
        if(s[i].isupper()):
            return True;
            break;
    return False;
 

    
if __name__ == '__main__':
    s = input()
    
    
    flagalphanum = fun1(s)
    alphabetical = fun2(s)
    digits = fun3(s)
    lowercase = fun4(s)
    uppercase = fun5(s)
    print(flagalphanum)
    print(alphabetical)
    print(digits)
    print(lowercase)
    print(uppercase)


# # 6 Text Allignment

# In[ ]:


thickness = int(input()) #This must be an odd number
c = 'H'

#Top Cone
for i in range(thickness):
    print((c*i).rjust(thickness-1)+c+(c*i).ljust(thickness-1))

#Top Pillars
for i in range(thickness+1):
    print((c*thickness).center(thickness*2)+(c*thickness).center(thickness*6))

#Middle Belt
for i in range((thickness+1)//2):
    print((c*thickness*5).center(thickness*6))    

#Bottom Pillars
for i in range(thickness+1):
    print((c*thickness).center(thickness*2)+(c*thickness).center(thickness*6))    

#Bottom Cone
for i in range(thickness):
    print(((c*(thickness-i-1)).rjust(thickness)+c+(c*(thickness-i-1)).ljust(thickness)).rjust(thickness*6))


# # 7 Text Wrap

# In[ ]:


import textwrap

def wrap(string, max_width):
    return "\n".join(textwrap.wrap(string, max_width))    
    

if __name__ == '__main__':
    string, max_width = input(), int(input())
    result = wrap(string, max_width)
    print(result)


# # 8 Design Dor Mat

# In[ ]:


n, m = map(int,input().split())
p = [('.|.'*(2*i + 1)).center(m, '-') for i in range(n//2)]
print('\n'.join(p + ['WELCOME'.center(m, '-')] + p[::-1]))


# # 9 String Formatting

# In[ ]:


def print_formatted(number):
    l1 = len(bin(number)[2:])
    for i in range(1,number+1):
        print(str(i).rjust(l1,' '),end=" ")
        print(oct(i)[2:].rjust(l1,' '),end=" ")
        print(((hex(i)[2:]).upper()).rjust(l1,' '),end=" ")
        print(bin(i)[2:].rjust(l1,' '),end=" ")
        print("")

if __name__ == '__main__':
    n = int(input())
    print_formatted(n)


# # 10 Alphabet Rangoli

# In[ ]:


width  = size*4-3
    string = ''

    for i in range(1,size+1):
        for j in range(0,i):
            string += chr(96+size-j)
            if len(string) < width :
                string += '-'
        for k in range(i-1,0,-1):    
            string += chr(97+size-k)
            if len(string) < width :
                string += '-'
        print(string.center(width,'-'))
        string = ''

    for i in range(size-1,0,-1):
        string = ''
        for j in range(0,i):
            string += chr(96+size-j)
            if len(string) < width :
                string += '-'
        for k in range(i-1,0,-1):
            string += chr(97+size-k)
            if len(string) < width :
                string += '-'
        print(string.center(width,'-'))


# # 11 Capitalize

# In[ ]:


ef solve(s):
    for i in s.split():
        s = s.replace(i,i.capitalize())
    return s

if __name__ == '__main__':
    fptr = open(os.environ['OUTPUT_PATH'], 'w')

    s = input()

    result = solve(s)

    fptr.write(result + '\n')

    fptr.close()


# # 12 The Minion Game

# In[ ]:


def minion_game(string):
    player1 = 0;
    player2 = 0;
    str_len = len(string)
    for i in range(str_len):
        if s[i] in "AEIOU":
            player1 += (str_len)-i
        else :
            player2 += (str_len)-i
    
    if player1 > player2:
        print("Kevin", player1)
    elif player1 < player2:
        print("Stuart",player2)
    elif player1 == player2:
        print("Draw")
    else :
        print("Draw")

if __name__ == '__main__':
    s = input()
    minion_game(s)


# # 13 Merge the tools

# In[ ]:


from collections import OrderedDict
def merge_the_tools(string, k):
    strlen = len(string)
    for i in range(0,strlen,k):
        print(''.join(OrderedDict.fromkeys(string[i:i + k])))# your code goes here

if __name__ == '__main__':
    string, k = input(), int(input())
    merge_the_tools(string, k)


# # 14  String Split and Join

# In[ ]:


def split_and_join(line):
    a=line.split()
    a='-'.join(a)
    return a
    

if __name__ == '__main__':
    line = input()
    result = split_and_join(line)
    print(result)

